import { ReactNode } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface SectionProps {
  id: string;
  title?: string;
  children: ReactNode;
  className?: string;
  background?: "default" | "muted" | "dark";
}

export function Section({ id, title, children, className, background = "default" }: SectionProps) {
  const bgClasses = {
    default: "bg-background",
    muted: "bg-secondary/30",
    dark: "bg-primary text-primary-foreground",
  };

  return (
    <section id={id} className={cn(bgClasses[background], className)}>
      <div className="container-section">
        {title && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className={cn(
              "section-title",
              background === "dark" ? "text-primary-foreground before:bg-primary-foreground" : ""
            )}>
              {title}
            </h2>
          </motion.div>
        )}
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          {children}
        </motion.div>
      </div>
    </section>
  );
}
