import { Navigation } from "@/components/Navigation";
import { Section } from "@/components/Section";
import { ContactForm } from "@/components/ContactForm";
import { Button } from "@/components/ui/button";
import { 
  ArrowRight, 
  Linkedin, 
  Mail, 
  MapPin, 
  Phone, 
  Briefcase,
  GraduationCap,
  Award,
  BarChart,
  Search,
  Users
} from "lucide-react";
import { motion } from "framer-motion";
import profileImg from "@assets/1740974467425_1768380005790.jpg";

export default function Home() {
  const scrollToContact = () => {
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-background font-sans text-foreground selection:bg-primary/10">
      <Navigation />

      {/* Hero Section */}
      <section id="hero" className="relative min-h-screen flex items-center pt-20">
        <div className="absolute inset-0 z-0 opacity-5 bg-[radial-gradient(#000000_1px,transparent_1px)] [background-size:16px_16px]"></div>
        
        <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="inline-block px-3 py-1 mb-6 text-sm font-medium tracking-wide border border-primary/20 rounded-full bg-secondary/50">
              Executive Researcher
            </div>
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-display font-bold leading-tight mb-6">
              Rajendra <span className="text-muted-foreground">Suthar</span>
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground font-light mb-8 max-w-xl">
              Strategic Executive Researcher | 9+ Years of Experience. Expert, delivering talent mapping from initial-level roles to C-suite mandates. A trusted partner to Hiring Managers and TA leads, leveraging market intelligence to build high-impact leadership pipelines for business-critical hires.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <Button size="lg" onClick={scrollToContact} className="h-14 px-8 text-lg">
                Get in Touch
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </div>

            <div className="flex flex-col gap-3 text-sm text-muted-foreground">
              <a href="mailto:rajendrasutharudr@gmail.com" className="flex items-center hover:text-primary transition-colors">
                <Mail className="w-4 h-4 mr-3" />
                rajendrasutharudr@gmail.com
              </a>
              <a href="tel:+917691003939" className="flex items-center hover:text-primary transition-colors">
                <Phone className="w-4 h-4 mr-3" />
                +91 76910 03939
              </a>
              <div className="flex items-center">
                <MapPin className="w-4 h-4 mr-3" />
                LB 202, Silver Residency, Thoor, Udaipur (Raj.)
              </div>
              <a href="https://www.linkedin.com/in/rajendra-suthar-5208532a9" target="_blank" rel="noopener noreferrer" className="flex items-center hover:text-primary transition-colors">
                <Linkedin className="w-4 h-4 mr-3" />
                LinkedIn Profile
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="hidden lg:block relative"
          >
            <div className="absolute inset-0 bg-gradient-to-tr from-primary/5 to-transparent rounded-3xl transform rotate-3 scale-105"></div>
            <div className="relative aspect-square rounded-2xl overflow-hidden shadow-2xl bg-muted border border-border">
              <img 
                src={profileImg} 
                alt="Rajendra Suthar" 
                className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
              />
            </div>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <Section id="about" background="muted" className="py-24">
        <div className="grid md:grid-cols-12 gap-12 items-start">
          <div className="md:col-span-5 relative">
            <h2 className="text-4xl font-display font-bold mb-6">Professional Summary</h2>
            <div className="w-20 h-1 bg-primary mb-8"></div>
          </div>
          <div className="md:col-span-7">
            <p className="text-lg leading-relaxed text-muted-foreground mb-6">
              Strategic Executive Researcher | 9+ Years of Experience. Expert, delivering talent mapping from initial-level roles to C-suite mandates. A trusted partner to Hiring Managers and TA leads, leveraging market intelligence to build high-impact leadership pipelines for business-critical hires.
            </p>
            <p className="text-lg leading-relaxed text-muted-foreground mb-8">
              Talent Sourcing, Business Development, Venture Capital Funding, Mapping, Primary Research, Secondary Research, Legal Research, Financial Research, Tech. Research, Health Research, etc.
            </p>
            
            <div className="grid grid-cols-2 gap-4">
              {[
                "Talent Sourcing",
                "Business Development",
                "Venture Capital Funding",
                "Mapping",
                "Primary Research",
                "Secondary Research",
                "Legal Research",
                "Financial Research",
                "Tech. Research",
                "Health Research"
              ].map((item) => (
                <div key={item} className="flex items-center text-sm font-medium">
                  <div className="w-2 h-2 rounded-full bg-primary mr-3"></div>
                  {item}
                </div>
              ))}
            </div>
          </div>
        </div>
      </Section>

      {/* Experience Section */}
      <Section id="experience" title="Work Experience">
        <div className="space-y-12">
          {/* Job 1 */}
          <div className="relative pl-8 md:pl-0">
            <div className="hidden md:block absolute left-1/2 -translate-x-1/2 top-0 bottom-0 w-px bg-border"></div>
            
            <div className="md:flex items-start justify-between group">
              <div className="md:w-[45%] mb-4 md:mb-0 md:text-right md:pr-12">
                <div className="inline-block px-3 py-1 rounded-full bg-primary/5 text-primary text-sm font-medium mb-2">
                  Sep 2019 - Present
                </div>
                <h3 className="text-2xl font-bold text-foreground group-hover:text-primary transition-colors">Senior Research Associate</h3>
                <p className="text-muted-foreground font-medium">AM Research Services</p>
              </div>
              
              <div className="absolute left-0 md:left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-background border-4 border-primary z-10 mt-2"></div>
              
              <div className="md:w-[45%] md:pl-12">
                <ul className="space-y-3 text-muted-foreground text-sm leading-relaxed">
                  <li className="flex items-start">
                    <span className="mr-2 mt-1.5 w-1.5 h-1.5 bg-primary/60 rounded-full flex-shrink-0"></span>
                    <span><strong className="text-foreground">Stakeholder Partnership:</strong> Consult with Hiring Managers and TA leads to define search strategies for business-critical roles.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 mt-1.5 w-1.5 h-1.5 bg-primary/60 rounded-full flex-shrink-0"></span>
                    <span><strong className="text-foreground">Full-Spectrum Mapping:</strong> Execute talent mapping, from entry-level to C-suite mandates.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 mt-1.5 w-1.5 h-1.5 bg-primary/60 rounded-full flex-shrink-0"></span>
                    <span><strong className="text-foreground">Executive Intelligence:</strong> Conduct competitor org-chart reconstruction and deep-web sourcing to identify top-tier leadership.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 mt-1.5 w-1.5 h-1.5 bg-primary/60 rounded-full flex-shrink-0"></span>
                    <span><strong className="text-foreground">Pipeline Building:</strong> Curate robust candidate pools for niche and high-priority executive assignments.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 mt-1.5 w-1.5 h-1.5 bg-primary/60 rounded-full flex-shrink-0"></span>
                    <span><strong className="text-foreground">Resource Allocation:</strong> Managed daily workforce distribution and resource scheduling to ensure optimal project coverage.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 mt-1.5 w-1.5 h-1.5 bg-primary/60 rounded-full flex-shrink-0"></span>
                    <span><strong className="text-foreground">Client Relations:</strong> Led project discovery and status calls with clients to align on deliverables and timelines.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 mt-1.5 w-1.5 h-1.5 bg-primary/60 rounded-full flex-shrink-0"></span>
                    <span><strong className="text-foreground">Market Intelligence:</strong> Tracked senior industry leader commentary and "Interesting Bites" to identify emerging market trends.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 mt-1.5 w-1.5 h-1.5 bg-primary/60 rounded-full flex-shrink-0"></span>
                    <span><strong className="text-foreground">Executive Tracking:</strong> Monitored executive moves and company news to provide real-time updates on industry leadership shifts.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 mt-1.5 w-1.5 h-1.5 bg-primary/60 rounded-full flex-shrink-0"></span>
                    <span>Conducted secondary research and competitive analysis to identify potential market growth opportunities.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 mt-1.5 w-1.5 h-1.5 bg-primary/60 rounded-full flex-shrink-0"></span>
                    <span>Generated sales and pipeline reports, product benchmarking, and market forecasts to support business decision-making.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 mt-1.5 w-1.5 h-1.5 bg-primary/60 rounded-full flex-shrink-0"></span>
                    <span>Provided market insights and industry/sector analysis to drive strategic initiatives for business growth.</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Job 2 */}
          <div className="relative pl-8 md:pl-0">
            <div className="hidden md:block absolute left-1/2 -translate-x-1/2 top-0 bottom-0 w-px bg-border"></div>
            
            <div className="md:flex items-start justify-between group">
              <div className="md:w-[45%] mb-4 md:mb-0 md:text-right md:pr-12">
                <div className="inline-block px-3 py-1 rounded-full bg-secondary text-secondary-foreground text-sm font-medium mb-2">
                  Dec 2015 - Dec 2018
                </div>
                <h3 className="text-2xl font-bold text-foreground group-hover:text-primary transition-colors">Research Associate</h3>
                <p className="text-muted-foreground font-medium">Arcgate Technologies LLP</p>
              </div>
              
              <div className="absolute left-0 md:left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-background border-4 border-muted-foreground z-10 mt-2"></div>
              
              <div className="md:w-[45%] md:pl-12">
                <ul className="space-y-3 text-muted-foreground text-sm leading-relaxed text-left">
                  <li className="flex items-start">
                    <span className="mr-2 mt-1.5 w-1.5 h-1.5 bg-primary/60 rounded-full flex-shrink-0"></span>
                    <span>Worked in an US client based Outsourcing firm ArcGate and providing meaningful contribution by undertaking different types of business analysis and research task.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 mt-1.5 w-1.5 h-1.5 bg-primary/60 rounded-full flex-shrink-0"></span>
                    <span>Contributed to business development efforts</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </Section>

      {/* Skills Section */}
      <Section id="skills" title="Expertise & Tools" background="muted">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-card p-8 rounded-xl shadow-sm border border-border/50 hover:shadow-md transition-shadow">
            <div className="w-12 h-12 bg-primary/5 rounded-lg flex items-center justify-center mb-6 text-primary">
              <BarChart size={24} />
            </div>
            <h3 className="text-xl font-bold mb-4">Tools & IT</h3>
            <div className="flex flex-wrap gap-2">
              {[
                "Dashboard preparation in Power BI", "VLOOKUP", "Pivot Tables", 
                "Microsoft Suite", "SQL", "AI AI to Web/Tool/Apps build", 
                "Apollo.io", "RocketReach", "Sales Navigator (LinkedIn)", 
                "Recruiter (LinkedIn)", "Recruiterflow (ATS & CRM)", 
                "Replit (Cloud-based development platform)"
              ].map(skill => (
                <span key={skill} className="px-3 py-1 text-xs font-medium bg-secondary text-secondary-foreground rounded-md border border-border">
                  {skill}
                </span>
              ))}
            </div>
          </div>

          <div className="bg-card p-8 rounded-xl shadow-sm border border-border/50 hover:shadow-md transition-shadow">
            <div className="w-12 h-12 bg-primary/5 rounded-lg flex items-center justify-center mb-6 text-primary">
              <Search size={24} />
            </div>
            <h3 className="text-xl font-bold mb-4">Core Competencies</h3>
            <div className="flex flex-wrap gap-2">
              {[
                "Boolean String Search", "Talent Sourcing", 
                "Secondary Research", "Leadership", 
                "Teamwork", "Project Management", 
                "Time Management", "Effective Communication"
              ].map(skill => (
                <span key={skill} className="px-3 py-1 text-xs font-medium bg-secondary text-secondary-foreground rounded-md border border-border">
                  {skill}
                </span>
              ))}
            </div>
          </div>

          <div className="bg-card p-8 rounded-xl shadow-sm border border-border/50 hover:shadow-md transition-shadow">
            <div className="w-12 h-12 bg-primary/5 rounded-lg flex items-center justify-center mb-6 text-primary">
              <Users size={24} />
            </div>
            <h3 className="text-xl font-bold mb-4">Languages</h3>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p><strong className="text-foreground">English</strong>-Read, Write, Speak</p>
              <p><strong className="text-foreground">Hindi</strong>-Read, Write, Speak</p>
            </div>
          </div>
        </div>
      </Section>

      {/* Education & Certifications */}
      <Section id="education" title="Education & Certifications">
        <div className="grid md:grid-cols-2 gap-12">
          {/* Education */}
          <div>
            <div className="flex items-center mb-8">
              <GraduationCap className="mr-3 text-primary" size={28} />
              <h3 className="text-2xl font-bold">Education</h3>
            </div>
            
            <div className="space-y-8">
              <div className="border-l-2 border-primary/20 pl-6 relative">
                <div className="absolute -left-[5px] top-0 w-2.5 h-2.5 rounded-full bg-primary"></div>
                <h4 className="text-lg font-bold">MBA (Finance, General)</h4>
                <p className="text-primary font-medium mb-1">Manipal University Jaipur</p>
                <p className="text-sm text-muted-foreground">Aug 2024 - Pursuing</p>
              </div>
              
              <div className="border-l-2 border-primary/20 pl-6 relative">
                <div className="absolute -left-[5px] top-0 w-2.5 h-2.5 rounded-full bg-muted-foreground"></div>
                <h4 className="text-lg font-bold">BBA (Economics)</h4>
                <p className="text-primary font-medium mb-1">Mohanlal Sukhadia University, Udaipur</p>
                <p className="text-sm text-muted-foreground">2011 - 2014</p>
              </div>
            </div>
          </div>

          {/* Certifications */}
          <div>
            <div className="flex items-center mb-8">
              <Award className="mr-3 text-primary" size={28} />
              <h3 className="text-2xl font-bold">Certifications</h3>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              {[
                { name: "Research Methodologies (2026)", org: "Coursera (Issue by Queen Mary University of London)", url: "https://www.coursera.org/account/accomplishments/verify/TRT7E9CDSQLK" },
                { name: "Finance of Mergers and Acquisitions: Valuation and Pricing (2026)", org: "Coursera (Issue by University of Illinois Urbana-Champaign)", url: "https://www.coursera.org/account/accomplishments/verify/TCTUH4AC44XM" },
                { name: "Sales and CRM Overview (2024)", org: "Coursera (Issue by Salesforce)", url: "https://www.coursera.org/account/accomplishments/verify/B9TZ2L2QGXCL" },
                { name: "Foundations of Project Management (2024)", org: "Coursera (Issue by Google)", url: "https://www.coursera.org/learn/project-management-foundations" },
                { name: "Introduction to Business Analytics (2024)", org: "Coursera (Issue by Tableau Learning Partner)", url: "https://www.coursera.org/account/accomplishments/verify/VB8DPFH5UQY4" },
                { name: "Preparing Data for Analysis with Microsoft Excel (2024)", org: "Coursera (Issue by Microsoft)", url: "https://www.coursera.org/account/accomplishments/verify/PDUDZ3MMRL5Q" },
              ].map((cert, idx) => (
                <div key={idx} className="flex justify-between items-start pb-4 border-b border-border/50 last:border-0">
                  <div>
                    <a 
                      href={cert.url} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="font-semibold text-foreground hover:text-primary transition-colors hover:underline decoration-1 underline-offset-4"
                    >
                      {cert.name}
                    </a>
                    <p className="text-sm text-muted-foreground">{cert.org}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Section>

      {/* Contact Section */}
      <Section id="contact" background="dark" className="py-24">
        <div className="grid md:grid-cols-2 gap-12 lg:gap-24">
          <div>
            <h2 className="text-4xl md:text-5xl font-display font-bold mb-6 text-primary-foreground">Let's Connect</h2>
            <p className="text-lg text-primary-foreground/70 mb-12">
              Interested in discussing market intelligence, talent mapping, or potential collaborations? I'm always open to new opportunities and professional networking.
            </p>

            <div className="space-y-6">
              <div className="flex items-start">
                <div className="w-12 h-12 rounded-full bg-primary-foreground/10 flex items-center justify-center mr-6 flex-shrink-0 text-primary-foreground">
                  <Phone size={20} />
                </div>
                <div>
                  <h4 className="text-sm font-medium text-primary-foreground/50 uppercase tracking-wider mb-1">Phone</h4>
                  <p className="text-lg font-medium text-primary-foreground">+91 76910 03939</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="w-12 h-12 rounded-full bg-primary-foreground/10 flex items-center justify-center mr-6 flex-shrink-0 text-primary-foreground">
                  <Mail size={20} />
                </div>
                <div>
                  <h4 className="text-sm font-medium text-primary-foreground/50 uppercase tracking-wider mb-1">Email</h4>
                  <p className="text-lg font-medium text-primary-foreground">rajendrasutharudr@gmail.com</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="w-12 h-12 rounded-full bg-primary-foreground/10 flex items-center justify-center mr-6 flex-shrink-0 text-primary-foreground">
                  <MapPin size={20} />
                </div>
                <div>
                  <h4 className="text-sm font-medium text-primary-foreground/50 uppercase tracking-wider mb-1">Location</h4>
                  <p className="text-lg font-medium text-primary-foreground">LB 202, Silver Residency<br/>Thoor, Udaipur (Raj.)</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="w-12 h-12 rounded-full bg-primary-foreground/10 flex items-center justify-center mr-6 flex-shrink-0 text-primary-foreground">
                  <Linkedin size={20} />
                </div>
                <div>
                  <h4 className="text-sm font-medium text-primary-foreground/50 uppercase tracking-wider mb-1">Social</h4>
                  <a href="https://www.linkedin.com/in/rajendra-suthar-5208532a9" target="_blank" rel="noopener noreferrer" className="text-lg font-medium text-primary-foreground hover:text-primary-foreground/80 underline decoration-1 underline-offset-4">
                    LinkedIn Profile
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div className="text-foreground">
            <ContactForm />
          </div>
        </div>
      </Section>

      <footer className="bg-primary text-primary-foreground border-t border-primary-foreground/10 py-8">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-primary-foreground/60 mb-4 md:mb-0">
            © {new Date().getFullYear()} Rajendra Suthar. All rights reserved.
          </p>
          <div className="flex space-x-6 text-sm text-primary-foreground/60">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
