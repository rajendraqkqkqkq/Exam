## Packages
framer-motion | Smooth scroll animations and entry effects
react-hook-form | Form state management
@hookform/resolvers | Zod validation for forms
clsx | Class name conditional utility
tailwind-merge | Utility for merging tailwind classes

## Notes
API endpoint for contact form is POST /api/contact
The design follows a strict grey/black professional minimal theme.
Google Fonts: 'Inter' (sans) and 'Playfair Display' (serif/display) will be used.
