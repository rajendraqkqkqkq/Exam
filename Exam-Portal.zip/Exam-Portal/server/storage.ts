import { exams, type Exam, type InsertExam } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  createExam(exam: InsertExam): Promise<Exam>;
  getExam(id: number): Promise<Exam | undefined>;
  getAllExams(): Promise<Exam[]>;
  updateExam(id: number, exam: Partial<InsertExam>): Promise<Exam>;
  deleteExam(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async createExam(insertExam: InsertExam): Promise<Exam> {
    const [exam] = await db.insert(exams).values(insertExam).returning();
    return exam;
  }

  async getExam(id: number): Promise<Exam | undefined> {
    const [exam] = await db.select().from(exams).where(eq(exams.id, id));
    return exam;
  }

  async getAllExams(): Promise<Exam[]> {
    return await db.select().from(exams).orderBy(exams.submittedAt);
  }

  async updateExam(id: number, updateExam: Partial<InsertExam>): Promise<Exam> {
    const [exam] = await db.update(exams)
      .set(updateExam)
      .where(eq(exams.id, id))
      .returning();
    return exam;
  }

  async deleteExam(id: number): Promise<void> {
    await db.delete(exams).where(eq(exams.id, id));
  }
}

export const storage = new DatabaseStorage();
