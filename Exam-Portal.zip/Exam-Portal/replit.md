# AM Research Services - Executive Evaluation Portal

## Overview

This is an Executive Evaluation Portal for AM Research Services Private Limited. The application serves as a timed exam system where users can submit structured data about executives, companies, and news articles for evaluation purposes. It features a timer-based exam workflow with password-protected administrative actions, form validation, and Excel export capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state management
- **Forms**: React Hook Form with Zod validation and useFieldArray for dynamic lists
- **UI Components**: Shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Build Tool**: Vite with path aliases (@/, @shared/, @assets/)

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful endpoints defined in shared/routes.ts with Zod schemas
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Development**: tsx for TypeScript execution, Vite dev server with HMR

### Data Storage
- **Database**: PostgreSQL (connection via DATABASE_URL environment variable)
- **Schema**: Single `exams` table with JSONB columns for complex/array fields (executives, companies, past_companies, commenting_executives, interesting_bites)
- **Migrations**: Drizzle Kit for schema migrations (output to ./migrations)

### Key Design Patterns
- **Shared Types**: Schema and route definitions in /shared folder, consumed by both client and server
- **Type Safety**: End-to-end type safety using Zod schemas with drizzle-zod integration
- **Component Structure**: Reusable form sections (FormSection, DynamicList) with consistent styling
- **Password Protection**: Administrative actions (timer reset, URL editing) require password "AMR123"

### Build Configuration
- **Client Build**: Vite outputs to dist/public
- **Server Build**: esbuild bundles server with selective dependency bundling for faster cold starts
- **Production**: Single dist/index.cjs entry point serving static files

## External Dependencies

### Database
- **PostgreSQL**: Primary data store, requires DATABASE_URL environment variable
- **connect-pg-simple**: Session storage in PostgreSQL

### Third-Party Libraries
- **xlsx**: Excel file export for exam data
- **date-fns**: Date formatting and manipulation
- **Zod**: Runtime type validation for API inputs/outputs
- **Radix UI**: Accessible UI primitives (dialog, select, radio-group, etc.)

### Development Tools
- **@replit/vite-plugin-runtime-error-modal**: Error overlay in development
- **@replit/vite-plugin-cartographer**: Replit-specific development tooling
- **@replit/vite-plugin-dev-banner**: Development environment indicator