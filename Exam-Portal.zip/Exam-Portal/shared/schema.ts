import { pgTable, text, serial, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Structured types for JSON columns
export const executiveSchema = z.object({
  name: z.string(),
  title: z.string(),
  location: z.string(),
  gender: z.string(),
  linkedinUrl: z.string().optional(),
});

export const companySchema = z.object({
  name: z.string(),
  headquarters: z.string(),
  description: z.string(),
});

export const commentingExecutiveSchema = z.object({
  name: z.string(),
  title: z.string(),
});

export const exams = pgTable("exams", {
  id: serial("id").primaryKey(),
  
  // Interviewee Details
  applicantName: text("applicant_name"),
  contactNumber: text("contact_number"),
  address: text("address"),
  
  newsUrl: text("news_url"),
  date: text("date"),
  
  // Complex/Array fields stored as JSONB
  executives: jsonb("executives").$type<z.infer<typeof executiveSchema>[]>().default([]),
  companies: jsonb("companies").$type<z.infer<typeof companySchema>[]>().default([]),
  
  newsType: text("news_type"),
  
  pastCompanies: jsonb("past_companies").$type<string[]>().default([]),
  
  reportToName: text("report_to_name"),
  reportToTitle: text("report_to_title"),
  
  commentingExecutives: jsonb("commenting_executives").$type<z.infer<typeof commentingExecutiveSchema>[]>().default([]),
  commentary: text("commentary"),
  interestingBites: jsonb("interesting_bites").$type<string[]>().default([]),
  publicationName: text("publication_name"),
  
  // Evaluation fields
  status: text("status"), // Selected, Not Selected, Que
  remarks: text("remarks"),
  
  submittedAt: timestamp("submitted_at").defaultNow(),
});

export const insertExamSchema = createInsertSchema(exams).omit({ 
  id: true, 
  submittedAt: true 
});

export type Exam = typeof exams.$inferSelect;
export type InsertExam = z.infer<typeof insertExamSchema>;
