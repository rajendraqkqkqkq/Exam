## Packages
xlsx | For exporting exam data to Excel files
date-fns | For date formatting and manipulation

## Notes
Timer requires password "AMR123" to reset.
News URL requires password "AMR123" to edit.
Dynamic arrays (executives, companies, etc.) implemented with react-hook-form useFieldArray.
