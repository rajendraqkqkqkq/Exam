import { useState, useRef } from "react";
import { useForm, useFieldArray, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import * as XLSX from "xlsx";
import { format } from "date-fns";
import { Plus, Trash2, Lock, Unlock, Download, Send, RefreshCw, Save, CheckCircle2 } from "lucide-react";

import { insertExamSchema } from "@shared/schema";
import { useCreateExam, useUpdateExam } from "@/hooks/use-exams";
import { Header } from "@/components/Header";
import { Timer } from "@/components/Timer";
import { FormSection } from "@/components/FormSection";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";

// Extend schema for form handling
const formSchema = insertExamSchema.extend({
  date: z.string().default(() => format(new Date(), "yyyy-MM-dd")),
});

type FormValues = z.infer<typeof formSchema>;

export default function ExamPortal() {
  const [isExamStarted, setIsExamStarted] = useState(false);
  const [isExamFinished, setIsExamFinished] = useState(false);
  const [isUrlLocked, setIsUrlLocked] = useState(true);
  const [showUrlPasswordDialog, setShowUrlPasswordDialog] = useState(false);
  const [showEvaluationPasswordDialog, setShowEvaluationPasswordDialog] = useState(false);
  const [isEvaluationUnlocked, setIsEvaluationUnlocked] = useState(false);
  const [passwordInput, setPasswordInput] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [lastSavedId, setLastSavedId] = useState<number | null>(null);

  const createExam = useCreateExam();
  const updateExam = useUpdateExam();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      newsUrl: "",
      date: format(new Date(), "yyyy-MM-dd"),
      executives: [{ name: "", title: "", gender: "", location: "", linkedinUrl: "" }],
      companies: [{ name: "", headquarters: "", description: "" }],
      applicantName: "",
      contactNumber: "",
      address: "",
      pastCompanies: [""],
      commentingExecutives: [{ name: "", title: "" }],
      interestingBites: [""],
      newsType: "",
      reportToName: "",
      reportToTitle: "",
      commentary: "",
      publicationName: "",
      status: "Que",
      remarks: "",
    },
  });

  // Field Arrays for Dynamic Sections
  const { fields: executiveFields, append: appendExecutive, remove: removeExecutive } = useFieldArray({
    control: form.control,
    name: "executives",
  });
  
  const { fields: companyFields, append: appendCompany, remove: removeCompany } = useFieldArray({
    control: form.control,
    name: "companies",
  });

  const { fields: pastCompanyFields, append: appendPastCompany, remove: removePastCompany } = useFieldArray({
    control: form.control,
    name: "pastCompanies" as any,
  });

  const { fields: commentingExecFields, append: appendCommentingExec, remove: removeCommentingExec } = useFieldArray({
    control: form.control,
    name: "commentingExecutives",
  });

  const { fields: interestingBitesFields, append: appendInterestingBite, remove: removeInterestingBite } = useFieldArray({
    control: form.control,
    name: "interestingBites" as any,
  });

  // Actions
  const handleStartExam = () => {
    setIsExamStarted(true);
    setIsExamFinished(false);
    toast({
      title: "Exam Started",
      description: "You have 60 minutes to complete the test.",
    });
  };

  const handleTimeUp = () => {
    if (!isExamFinished) {
      form.handleSubmit(onSubmit)();
      toast({
        title: "Time's Up!",
        description: "Your exam has been automatically submitted.",
        variant: "destructive",
      });
    }
  };

  const handleResetExam = () => {
    setIsExamStarted(false);
    setIsExamFinished(false);
    setLastSavedId(null);
    form.reset();
    setIsUrlLocked(true);
    toast({ title: "Portal Reset", description: "Ready for the next candidate." });
  };

  const handleUrlUnlock = () => {
    setShowUrlPasswordDialog(true);
    setPasswordInput("");
    setPasswordError("");
  };

  const handleEvaluationUnlock = () => {
    setShowEvaluationPasswordDialog(true);
    setPasswordInput("");
    setPasswordError("");
  };

  const confirmUrlUnlock = () => {
    if (passwordInput === "AMR123") {
      setIsUrlLocked(false);
      setShowUrlPasswordDialog(false);
      setPasswordInput("");
      setPasswordError("");
    } else {
      setPasswordError("Incorrect password");
    }
  };

  const confirmEvaluationUnlock = () => {
    if (passwordInput === "AMR123") {
      setIsEvaluationUnlocked(true);
      setShowEvaluationPasswordDialog(false);
      setPasswordInput("");
      setPasswordError("");
    } else {
      setPasswordError("Incorrect password");
    }
  };

  const exportToExcel = () => {
    const data = form.getValues();
    
    // Flatten data for Excel
    const flatData = {
      applicantName: data.applicantName,
      contactNumber: data.contactNumber,
      address: data.address,
      ...data,
      executives: (data.executives || []).map((e: any) => `${e?.name || ''} (${e?.title || ''}, ${e?.gender || ''}, ${e?.location || ''})`).join("; "),
      companies: (data.companies || []).map((c: any) => `${c?.name || ''} - ${c?.headquarters || ''} (${c?.description || ''})`).join("; "),
      pastCompanies: data.pastCompanies?.join(", "),
      commentingExecutives: (data.commentingExecutives || []).map((e: any) => `${e?.name || ''} (${e?.title || ''})`).join("; "),
      interestingBites: data.interestingBites?.join("\n"),
    };

    const worksheet = XLSX.utils.json_to_sheet([flatData]);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Exam Data");
    XLSX.writeFile(workbook, `Candidate_Exam_${format(new Date(), "yyyyMMdd_HHmm")}.xlsx`);
    
    toast({ title: "Export Successful", description: "Excel file has been downloaded." });
  };

  const onSubmit = async (data: FormValues) => {
    try {
      if (lastSavedId) {
        await updateExam.mutateAsync({ id: lastSavedId, ...data });
        toast({ title: "Exam Updated", description: "Your changes have been saved." });
      } else {
        const result = await createExam.mutateAsync(data);
        setLastSavedId(result.id);
        toast({ title: "Exam Submitted", description: "Thank you for your submission." });
      }
      setIsExamFinished(true);
      setIsExamStarted(false);
    } catch (error) {
      toast({ 
        title: "Submission Failed", 
        description: (error as Error).message, 
        variant: "destructive" 
      });
    }
  };

  const isFrozen = (!isExamStarted && isUrlLocked) || isExamFinished;
  const isUrlSectionFrozen = isExamFinished;

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      <Header>
        <Timer 
          durationMinutes={60} 
          isRunning={isExamStarted} 
          onStart={handleStartExam}
          onTimeUp={handleTimeUp}
          onReset={() => {
            setIsExamStarted(false);
            setIsExamFinished(false);
          }}
          isFinished={isExamFinished}
        />
      </Header>

      <main className="container mx-auto px-4 py-8 max-w-5xl">
        <div className="space-y-8">
          {/* Section 0: Interviewee Details */}
          <FormSection title="Interviewee Details" description="Candidate personal information.">
            <div className="grid gap-6 md:grid-cols-3">
              <div className="space-y-2">
                <Label>Applicant Name <span className="text-destructive">*</span></Label>
                <Input {...form.register("applicantName")} placeholder="Full Name" disabled={isExamFinished} />
              </div>
              <div className="space-y-2">
                <Label>Contact Number <span className="text-destructive">*</span></Label>
                <Input {...form.register("contactNumber")} placeholder="Phone Number" disabled={isExamFinished} />
              </div>
              <div className="space-y-2">
                <Label>Address</Label>
                <Input {...form.register("address")} placeholder="Current Address" disabled={isExamFinished} />
              </div>
            </div>
          </FormSection>

          {isExamFinished && (
            <div className="mb-8 p-6 bg-green-50 border border-green-200 rounded-xl flex items-center gap-4 text-green-800 animate-in fade-in slide-in-from-top-4">
              <CheckCircle2 className="w-8 h-8 flex-shrink-0" />
              <div>
                <h2 className="text-xl font-bold font-display">Thank you so much for your time today.</h2>
                <p className="opacity-90">Your exam has been successfully submitted for evaluation.</p>
              </div>
            </div>
          )}

          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <fieldset disabled={isUrlSectionFrozen} className="contents">
              {/* Section 1: Source Info */}
              <FormSection title="Source Information" description="Enter the news source details first to begin.">
                <div className="grid gap-6 md:grid-cols-2">
                  <div className="md:col-span-2 space-y-2">
                    <Label>News URL <span className="text-destructive">*</span></Label>
                      <div className="flex gap-2 relative z-50">
                        <Input 
                          {...form.register("newsUrl")} 
                          disabled={isUrlLocked && !isExamFinished} 
                          className={isUrlLocked ? "bg-muted text-muted-foreground" : "bg-background"}
                          placeholder="https://..."
                        />
                        {isUrlLocked && !isExamFinished ? (
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              handleUrlUnlock();
                            }} 
                            title="Unlock URL field"
                            className="shrink-0"
                          >
                            <Lock className="w-4 h-4" />
                          </Button>
                        ) : (
                          <Button type="button" variant="ghost" disabled title="Unlocked" className="shrink-0">
                            <Unlock className="w-4 h-4 text-green-600" />
                          </Button>
                        )}
                      </div>
                    {!isExamStarted && !isExamFinished && (
                      <Button 
                        type="button" 
                        onClick={handleStartExam} 
                        className="w-full mt-2"
                        disabled={isUrlLocked}
                      >
                        Start Exam Timer
                      </Button>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Date</Label>
                    <Input type="date" {...form.register("date")} />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Publication Name</Label>
                    <Input {...form.register("publicationName")} placeholder="e.g. Wall Street Journal" />
                  </div>
                </div>
              </FormSection>
            </fieldset>

            <fieldset disabled={isFrozen} className="space-y-8 contents">

              {/* Section 2: Executive Details */}
              <FormSection title="Executive Details" description="Information about the key person(s) mentioned in the news.">
                <div className="space-y-6">
                  {executiveFields.map((field, index) => (
                    <div key={field.id} className="grid gap-4 md:grid-cols-5 p-4 bg-muted/20 rounded-lg border relative group items-end">
                      <div className="space-y-2">
                        <Label>Executive Name</Label>
                        <Input {...form.register(`executives.${index}.name` as any)} placeholder="Full Name" />
                      </div>
                      <div className="space-y-2">
                        <Label>Job Title</Label>
                        <Input {...form.register(`executives.${index}.title` as any)} placeholder="Current Title" />
                      </div>
                      <div className="space-y-2">
                        <Label>Gender</Label>
                        <Controller
                          control={form.control}
                          name={`executives.${index}.gender` as any}
                          render={({ field }) => (
                            <Select onValueChange={field.onChange} value={field.value || ""}>
                              <SelectTrigger>
                                <SelectValue placeholder="Select" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Male">Male</SelectItem>
                                <SelectItem value="Female">Female</SelectItem>
                              </SelectContent>
                            </Select>
                          )}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Location</Label>
                        <Input {...form.register(`executives.${index}.location` as any)} placeholder="City, Country" />
                      </div>
                      <div className="space-y-2">
                        <Label>LinkedIn URL</Label>
                        <Input {...form.register(`executives.${index}.linkedinUrl` as any)} placeholder="https://..." />
                      </div>
                      
                      {executiveFields.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="absolute -top-2 -right-2 h-6 w-6 rounded-full bg-destructive text-destructive-foreground hover:bg-destructive/90 shadow-sm opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => removeExecutive(index)}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="w-full border-dashed"
                    onClick={() => appendExecutive({ name: "", title: "", gender: "", location: "", linkedinUrl: "" })}
                  >
                    <Plus className="w-4 h-4 mr-2" /> Add Another Executive
                  </Button>

                  <Separator className="my-6" />
                  
                  <div className="grid gap-6 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Report To (Name)</Label>
                      <Input {...form.register("reportToName")} placeholder="Manager's Name" />
                    </div>

                    <div className="space-y-2">
                      <Label>Report To (Title)</Label>
                      <Input {...form.register("reportToTitle")} placeholder="Manager's Title" />
                    </div>
                  </div>
                </div>
              </FormSection>

              {/* Section 3: Company Information */}
              <FormSection title="Company Context" description="Details about the companies involved.">
                <div className="space-y-6">
                  {companyFields.map((field, index) => (
                    <div key={field.id} className="grid gap-4 md:grid-cols-3 p-4 bg-muted/20 rounded-lg border relative group items-end">
                      <div className="space-y-2">
                        <Label>Company Name</Label>
                        <Input {...form.register(`companies.${index}.name` as any)} placeholder="Company Name" />
                      </div>
                      <div className="space-y-2">
                        <Label>Headquarters</Label>
                        <Input {...form.register(`companies.${index}.headquarters` as any)} placeholder="HQ Location" />
                      </div>
                      <div className="space-y-2">
                        <Label>Company Description</Label>
                        <Input {...form.register(`companies.${index}.description` as any)} placeholder="Description..." />
                      </div>
                      {companyFields.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="absolute -top-2 -right-2 h-6 w-6 rounded-full bg-destructive text-destructive-foreground hover:bg-destructive/90 shadow-sm opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => removeCompany(index)}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button type="button" variant="outline" size="sm" className="w-full border-dashed" onClick={() => appendCompany({ name: "", headquarters: "", description: "" })}>
                    <Plus className="w-4 h-4 mr-2" /> Add Company
                  </Button>

                  <div className="grid gap-6 md:grid-cols-2 mt-6">
                    <div className="space-y-4">
                      <Label>Past Companies</Label>
                      {pastCompanyFields.map((field, index) => (
                        <div key={field.id} className="flex gap-2">
                          <Input {...form.register(`pastCompanies.${index}` as any)} placeholder="Past Company" />
                          {pastCompanyFields.length > 1 && (
                            <Button type="button" variant="ghost" size="icon" onClick={() => removePastCompany(index)}>
                              <Trash2 className="w-4 h-4 text-muted-foreground" />
                            </Button>
                          )}
                        </div>
                      ))}
                      <Button type="button" variant="outline" size="sm" onClick={() => appendPastCompany("")}>
                        <Plus className="w-3 h-3 mr-2" /> Add Past Company
                      </Button>
                    </div>

                    <div className="space-y-2">
                      <Label>News Type</Label>
                      <Controller
                        control={form.control}
                        name="newsType"
                        render={({ field }) => (
                          <Select onValueChange={field.onChange} value={field.value || undefined}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select Classification" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Arrival/Departure">Arrival/Departure</SelectItem>
                              <SelectItem value="Step Down">Step Down</SelectItem>
                              <SelectItem value="Retired">Retired</SelectItem>
                              <SelectItem value="Internal Move">Internal Move</SelectItem>
                              <SelectItem value="Other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        )}
                      />
                    </div>
                  </div>
                </div>
              </FormSection>

              {/* Section 4: Analysis & Commentary */}
              <FormSection title="Analysis & Commentary" description="Deeper insights and quotes.">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <Label>Commentary</Label>
                    <Textarea {...form.register("commentary")} placeholder="Strategic analysis..." className="min-h-[120px]" />
                  </div>

                  <div className="space-y-4">
                    <Label className="block">Commenting Executives</Label>
                    {commentingExecFields.map((field, index) => (
                      <div key={field.id} className="flex gap-3 items-start">
                        <div className="grid gap-2 flex-1 md:grid-cols-2">
                          <Input {...form.register(`commentingExecutives.${index}.name` as any)} placeholder="Executive Name" />
                          <Input {...form.register(`commentingExecutives.${index}.title` as any)} placeholder="Executive Title" />
                        </div>
                        {commentingExecFields.length > 1 && (
                           <Button type="button" variant="ghost" size="icon" onClick={() => removeCommentingExec(index)} className="mt-0">
                            <Trash2 className="w-4 h-4 text-muted-foreground" />
                          </Button>
                        )}
                      </div>
                    ))}
                    <Button type="button" variant="outline" size="sm" onClick={() => appendCommentingExec({ name: "", title: "" })}>
                      <Plus className="w-3 h-3 mr-2" /> Add Commenting Exec
                    </Button>
                  </div>

                  <div className="space-y-4">
                    <Label>Interesting Bites</Label>
                    {interestingBitesFields.map((field, index) => (
                      <div key={field.id} className="flex gap-2">
                        <Input {...form.register(`interestingBites.${index}` as any)} placeholder="Key takeaway or quote..." />
                        {interestingBitesFields.length > 1 && (
                          <Button type="button" variant="ghost" size="icon" onClick={() => removeInterestingBite(index)}>
                            <Trash2 className="w-4 h-4 text-muted-foreground" />
                          </Button>
                        )}
                      </div>
                    ))}
                    <Button type="button" variant="outline" size="sm" onClick={() => appendInterestingBite("")}>
                      <Plus className="w-3 h-3 mr-2" /> Add Bite
                    </Button>
                  </div>
                </div>
              </FormSection>
            </fieldset>

            {/* Section 5: Evaluation */}
            <div className={isExamFinished ? "block" : "hidden"}>
              {!isEvaluationUnlocked ? (
                <Card className="border-dashed">
                  <CardContent className="flex flex-col items-center justify-center py-10 gap-4">
                    <Lock className="w-10 h-10 text-muted-foreground" />
                    <div className="text-center">
                      <h3 className="font-bold text-lg">Evaluation Locked</h3>
                      <p className="text-muted-foreground text-sm">Authorized interviewer access only.</p>
                    </div>
                    <Button type="button" onClick={handleEvaluationUnlock} variant="outline" className="gap-2">
                      <Unlock className="w-4 h-4" /> Unlock Section
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <FormSection title="Evaluation" className="border-l-4 border-l-primary animate-in fade-in zoom-in-95 duration-300">
                  <div className="grid gap-6">
                    <div className="space-y-3">
                      <Label className="text-base">Decision</Label>
                      <Controller
                        control={form.control}
                        name="status"
                        render={({ field }) => (
                          <RadioGroup 
                            onValueChange={field.onChange} 
                            defaultValue={field.value || "Que"}
                            className="flex flex-col sm:flex-row gap-4"
                          >
                            <div className="flex items-center space-x-2 border rounded-lg p-3 hover:bg-muted/50 cursor-pointer transition-colors">
                              <RadioGroupItem value="Selected" id="r1" className="text-green-600 border-green-600" />
                              <Label htmlFor="r1" className="cursor-pointer font-normal">Selected</Label>
                            </div>
                            <div className="flex items-center space-x-2 border rounded-lg p-3 hover:bg-muted/50 cursor-pointer transition-colors">
                              <RadioGroupItem value="Not Selected" id="r2" className="text-red-600 border-red-600" />
                              <Label htmlFor="r2" className="cursor-pointer font-normal">Not Selected</Label>
                            </div>
                            <div className="flex items-center space-x-2 border rounded-lg p-3 hover:bg-muted/50 cursor-pointer transition-colors">
                              <RadioGroupItem value="Que" id="r3" />
                              <Label htmlFor="r3" className="cursor-pointer font-normal">Que</Label>
                            </div>
                          </RadioGroup>
                        )}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Evaluation Remarks</Label>
                      <Textarea {...form.register("remarks")} placeholder="Interviewer comments..." />
                    </div>
                  </div>
                </FormSection>
              )}
            </div>

            {/* Action Bar */}
            <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg z-40">
              <div className="container mx-auto max-w-5xl flex flex-wrap gap-4 items-center justify-between">
                <div className="flex gap-2">
                  <Button 
                    type="button" 
                    variant="destructive" 
                    onClick={() => {
                      handleResetExam();
                      setIsEvaluationUnlocked(false);
                    }}
                    className="gap-2"
                  >
                    <RefreshCw className="w-4 h-4" /> Clear Form
                  </Button>
                  
                  {isEvaluationUnlocked && (
                    <Button 
                      type="button" 
                      variant="secondary" 
                      onClick={exportToExcel}
                      className="gap-2 bg-green-50 text-green-700 hover:bg-green-100 border-green-200"
                    >
                      <Download className="w-4 h-4" /> Export Excel
                    </Button>
                  )}
                </div>

                <Button 
                  type="submit" 
                  size="lg"
                  className="gap-2 min-w-[150px] shadow-lg shadow-primary/20 hover:shadow-primary/30"
                  disabled={createExam.isPending || updateExam.isPending || (isFrozen && !isExamFinished)}
                >
                  {isExamFinished ? (
                    <> <Save className="w-4 h-4" /> Save Evaluation </>
                  ) : (
                    <> <Send className="w-4 h-4" /> Test Submit </>
                  )}
                </Button>
              </div>
            </div>
          </form>
        </div>
      </main>

      {/* URL Unlock & Evaluation Unlock Dialogs */}
      <Dialog 
        open={showUrlPasswordDialog || showEvaluationPasswordDialog} 
        onOpenChange={(open) => {
          if (!open) {
            setShowUrlPasswordDialog(false);
            setShowEvaluationPasswordDialog(false);
          }
        }}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{showUrlPasswordDialog ? "Unlock News URL" : "Unlock Evaluation Section"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Enter Password</Label>
              <Input
                type="password"
                value={passwordInput}
                onChange={(e) => {
                  setPasswordInput(e.target.value);
                  if (passwordError) setPasswordError("");
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    if (showUrlPasswordDialog) confirmUrlUnlock();
                    else confirmEvaluationUnlock();
                  }
                }}
                autoFocus
                className="bg-background"
              />
              {passwordError && <p className="text-sm text-destructive">{passwordError}</p>}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setShowUrlPasswordDialog(false);
              setShowEvaluationPasswordDialog(false);
            }}>Cancel</Button>
            <Button onClick={showUrlPasswordDialog ? confirmUrlUnlock : confirmEvaluationUnlock}>Unlock</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
