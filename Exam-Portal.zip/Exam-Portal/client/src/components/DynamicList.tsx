import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useFieldArray, Control, UseFormRegister, FieldValues, Path } from "react-hook-form";

interface DynamicListProps<T extends FieldValues> {
  control: Control<T>;
  register: UseFormRegister<T>;
  name: any; // Path<T> but simplified for generic complexity
  label: string;
  placeholder?: string;
  renderItem?: (index: number, remove: () => void) => React.ReactNode;
}

export function DynamicStringList<T extends FieldValues>({ 
  control, 
  register, 
  name, 
  label, 
  placeholder 
}: DynamicListProps<T>) {
  const { fields, append, remove } = useFieldArray({
    control,
    name,
  });

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <Label className="text-base text-primary/80">{label}</Label>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => append(" " as any)} // Append empty string
          className="h-8 text-xs border-dashed border-primary/40 text-primary hover:bg-primary/5"
        >
          <Plus className="w-3 h-3 mr-1" /> Add Row
        </Button>
      </div>
      
      {fields.map((field, index) => (
        <div key={field.id} className="flex gap-2 animate-in fade-in slide-in-from-left-4 duration-300">
          <Input
            {...register(`${name}.${index}` as any)}
            placeholder={placeholder}
            className="flex-1 bg-white"
          />
          {index > 0 && (
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={() => remove(index)}
              className="text-muted-foreground hover:text-destructive transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          )}
        </div>
      ))}
      
      {fields.length === 0 && (
        <Button
          type="button"
          variant="outline"
          className="w-full border-dashed text-muted-foreground"
          onClick={() => append(" " as any)}
        >
          <Plus className="w-4 h-4 mr-2" /> Start adding {label.toLowerCase()}
        </Button>
      )}
    </div>
  );
}
