import logoImg from "@assets/AMR_1768416342008.jfif";

export function Header({ children }: { children?: React.ReactNode }) {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 shadow-sm">
      <div className="container mx-auto px-4 h-20 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <img 
            src={logoImg} 
            alt="AM Research Services" 
            className="h-12 w-auto object-contain rounded-md"
          />
          <div className="hidden md:block">
            <h1 className="text-xl font-bold text-primary leading-tight">
              <a 
                href="https://www.amresearch.in/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="hover:text-accent transition-colors"
              >
                AM Research Services Private Limited
              </a>
            </h1>
            <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">
              Executive Evaluation Portal
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          {children}
        </div>
      </div>
    </header>
  );
}
