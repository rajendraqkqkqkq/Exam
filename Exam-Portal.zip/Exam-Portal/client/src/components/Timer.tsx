import { useState, useEffect } from "react";
import { Clock, RefreshCcw, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface TimerProps {
  durationMinutes: number;
  onTimeUp: () => void;
  onStart: () => void;
  isRunning: boolean;
  onReset: () => void;
  isFinished: boolean;
}

export function Timer({ durationMinutes, onTimeUp, onStart, isRunning, onReset, isFinished }: TimerProps) {
  const [timeLeft, setTimeLeft] = useState(durationMinutes * 60);
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [showStartPasswordDialog, setShowStartPasswordDialog] = useState(false);
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            onTimeUp();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [isRunning, timeLeft, onTimeUp]);

  useEffect(() => {
    // Reset local timer state when parent resets
    if (!isRunning && !isFinished && timeLeft === 0) {
       setTimeLeft(durationMinutes * 60);
    }
  }, [isRunning, isFinished, durationMinutes, timeLeft]);

  // Handle manual reset request from parent prop if needed, 
  // but here we manage the reset flow via the button
  const handleResetRequest = () => {
    setShowPasswordDialog(true);
    setPassword("");
    setError("");
  };

  const confirmReset = () => {
    if (password === "AMR123") {
      setTimeLeft(durationMinutes * 60);
      onReset();
      setShowPasswordDialog(false);
    } else {
      setError("Incorrect password");
    }
    setPassword("");
  };

  const confirmStart = () => {
    if (password === "AMR123") {
      onStart();
      setShowStartPasswordDialog(false);
    } else {
      setError("Incorrect password");
    }
    setPassword("");
  };

  const handleStartRequest = () => {
    setShowStartPasswordDialog(true);
    setPassword("");
    setError("");
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  // Determine color based on urgency
  const getTimerColor = () => {
    if (timeLeft < 300) return "text-destructive bg-destructive/10 border-destructive/20"; // Last 5 mins
    if (isRunning) return "text-primary bg-primary/5 border-primary/10";
    return "text-muted-foreground bg-muted border-border";
  };

  return (
    <div className="flex items-center gap-3">
      <div className={`
        flex items-center gap-2 px-4 py-2 rounded-lg border font-mono text-2xl font-bold transition-all duration-300
        ${getTimerColor()}
      `}>
        <Clock className="w-5 h-5" />
        {formatTime(timeLeft)}
      </div>

      <Button
        variant="outline"
        size="icon"
        onClick={handleResetRequest}
        title="Reset Timer"
        className="hover:bg-destructive/10 hover:text-destructive hover:border-destructive/30"
      >
        <RefreshCcw className="w-4 h-4" />
      </Button>

      <Dialog open={showStartPasswordDialog} onOpenChange={setShowStartPasswordDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Admin Authorization Required</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Enter Password to Start Exam</Label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter admin password"
                onKeyDown={(e) => e.key === 'Enter' && confirmStart()}
              />
              {error && <p className="text-sm text-destructive font-medium">{error}</p>}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowStartPasswordDialog(false)}>Cancel</Button>
            <Button onClick={confirmStart}>Confirm Start</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Admin Authorization Required</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Enter Password to Reset Timer</Label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter admin password"
                onKeyDown={(e) => e.key === 'Enter' && confirmReset()}
              />
              {error && <p className="text-sm text-destructive font-medium">{error}</p>}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPasswordDialog(false)}>Cancel</Button>
            <Button onClick={confirmReset}>Confirm Reset</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
